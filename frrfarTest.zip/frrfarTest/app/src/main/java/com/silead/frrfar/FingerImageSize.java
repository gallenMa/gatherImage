
package com.silead.frrfar;

public class FingerImageSize {
    public int width;
    public int height;

    public FingerImageSize() {
        width = FingerSettingsConst.OPTIC_SETTINGS_FINGER_IMAGE_WIDTH_DEFAULT;
        height = FingerSettingsConst.OPTIC_SETTINGS_FINGER_IMAGE_HEIGHT_DEFAULT;
    }
}
